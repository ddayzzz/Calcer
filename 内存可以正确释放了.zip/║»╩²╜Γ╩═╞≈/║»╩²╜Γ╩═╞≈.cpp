#include "base0.h"
int main()
{
	init_functionlist();
	std::string s = "sin(34)+3+9-sin(9+6)";
	std::vector<Log> lo;
	//auto p = Transfer_ExpToExpTree(s, 0, s.size() - 1,nullptr,&lo);
	//auto j = BuiltInFuntionCalc(nullptr, 2, nullptr);
	Expression ep(s,false,false);
	auto j = ep.Eval(nullptr, &lo);
	Number *nn = new Number(2.33);
	
	//�������ڴ��ظ��ͷ�
	//ExpNodeBase* nj = new Number(j->asLongDouble().first);
	//ExpNodeBase *nnn = new Number(*nn);
	Expression ep2("kk", true, true);
	std::vector<ExpNodeBase*> par{ j->clone(),nn->clone() };
	auto i=ep2.Eval(&par, &lo);
	ep2.~Expression();
	ep.~Expression();
	return 0;
}